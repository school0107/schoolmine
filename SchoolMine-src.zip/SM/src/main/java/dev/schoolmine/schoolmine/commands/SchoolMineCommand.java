package dev.schoolmine.schoolmine.commands;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;
public class SchoolMineCommand implements CommandExecutor,TabCompleter{
    private final SchoolMine plugin;
    public SchoolMineCommand(SchoolMine p){plugin=p;}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(args.length==0){help(sender);return true;}
        switch(args[0].toLowerCase()){
            case"reload"->{if(!sender.hasPermission("schoolmine.reload")){sender.sendMessage(plugin.getConfigManager().getMessage("no-permission"));return true;}plugin.reload();sender.sendMessage(plugin.getConfigManager().getMessage("reload-success"));}
            case"status"->{if(!(sender instanceof Player p)){sender.sendMessage("§cOnly players!");return true;}var d=plugin.getPlayerDataManager().get(p);var bm=plugin.getBoosterManager();p.sendMessage("§8[§6SchoolMine§8] §7Status:");p.sendMessage("§7AutoPickup: "+(d.isAutoPickup()?"§aON":"§cOFF"));p.sendMessage("§73x3: "+(d.isMining3x3()?"§aON":"§cOFF"));p.sendMessage("§7AutoSmelt: "+(d.isAutoSmelt()?"§aON":"§cOFF"));p.sendMessage("§7AutoMine: "+(d.isAutoMine()?"§aON":"§cOFF"));p.sendMessage("§7BlockRemove Queue: §e"+plugin.getBlockRemoveManager().getQueueSize());}
            default->help(sender);}
        return true;}
    private void help(CommandSender s){s.sendMessage("§8§m-----§r§8[§6SchoolMine§8]§8§m-----");s.sendMessage("§e/autopickup §7- Toggle auto pickup");s.sendMessage("§e/3x3 §7- Toggle 3x3 mining");s.sendMessage("§e/autosmelt §7- Toggle auto smelt");s.sendMessage("§e/automine §7- Toggle auto mine");s.sendMessage("§e/booster §7- Open booster menu");s.sendMessage("§e/schoolmine reload|status §7- Admin");s.sendMessage("§8§m------------------");}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String l,String[] a){return a.length==1?Arrays.asList("reload","status","help"):List.of();}
}
