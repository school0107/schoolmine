package dev.schoolmine.schoolmine.commands;
import dev.schoolmine.schoolmine.SchoolMine;
import dev.schoolmine.schoolmine.managers.PlayerData;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;
public class AutoMineCommand implements CommandExecutor, TabCompleter {
    private final SchoolMine plugin;
    public AutoMineCommand(SchoolMine p){plugin=p;}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(!(sender instanceof Player player)){sender.sendMessage("§cOnly players!");return true;}
        if(!player.hasPermission("schoolmine.automine")){player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));return true;}
        PlayerData data=plugin.getPlayerDataManager().get(player);
        boolean newState;
        if(args.length==0)newState=!data.isAutoMine();
        else switch(args[0].toLowerCase()){case"on"->newState=true;case"off"->newState=false;default->{player.sendMessage("§eUsage: /automine [on|off]");return true;}}
        data.setAutoMine(newState);
        player.sendMessage(plugin.getConfigManager().getMessage(newState?"automine-on":"automine-off"));
        return true;
    }
    @Override public List<String> onTabComplete(CommandSender s,Command c,String l,String[] a){if(a.length==1)return Arrays.asList("on","off");return List.of();}
}
