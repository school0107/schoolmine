package dev.schoolmine.schoolmine.listeners;
import dev.schoolmine.schoolmine.SchoolMine;
import dev.schoolmine.schoolmine.gui.BoosterMenu;
import dev.schoolmine.schoolmine.gui.BoosterMenu.MenuPage;
import dev.schoolmine.schoolmine.managers.BoosterManager;
import dev.schoolmine.schoolmine.managers.BoosterManager.BoosterType;
import org.black_ixx.playerpoints.PlayerPointsAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
public class BoosterMenuListener implements Listener {
    private final SchoolMine plugin;
    public BoosterMenuListener(SchoolMine p){plugin=p;}
    @EventHandler public void onClick(InventoryClickEvent event){
        if(!(event.getWhoClicked() instanceof Player player))return;
        Inventory clicked=event.getClickedInventory();if(clicked==null)return;
        Object holder=clicked.getHolder();if(!(holder instanceof BoosterMenu menu))return;
        event.setCancelled(true);int slot=event.getSlot();if(event.getCurrentItem()==null)return;
        switch(menu.getPage()){
            case MAIN->handleMain(player,slot);
            case PERSONAL_3X3,SERVER_3X3,PERSONAL_MULTI,SERVER_MULTI,PERSONAL_NUKER,SERVER_NUKER,PERSONAL_KILL_SHARD,SERVER_KILL_SHARD->handlePurchase(player,menu,slot);}
    }
    private void handleMain(Player player,int slot){
        MenuPage next=switch(slot){case 19->MenuPage.PERSONAL_3X3;case 21->MenuPage.SERVER_3X3;case 23->MenuPage.PERSONAL_MULTI;case 25->MenuPage.SERVER_MULTI;case 38->MenuPage.PERSONAL_NUKER;case 40->MenuPage.SERVER_NUKER;case 47->MenuPage.PERSONAL_KILL_SHARD;case 51->MenuPage.SERVER_KILL_SHARD;default->null;};
        if(next==null)return;player.closeInventory();player.openInventory(new BoosterMenu(plugin,player,next).build());}
    private void handlePurchase(Player player,BoosterMenu menu,int slot){
        if(slot==49){player.closeInventory();player.openInventory(new BoosterMenu(plugin,player,MenuPage.MAIN).build());return;}
        long durationMs=menu.getDurationMsFromSlot(slot);String dKey=menu.getDurationKeyFromSlot(slot);
        if(durationMs<0||dKey==null)return;
        BoosterType type=menu.getTypeFromPage();boolean server=menu.isServerPage();
        String typeKey=switch(type){case MINING_3X3->"mining-3x3";case MULTI_BLOCK->"multi-block";case NUKER->"nuker";case KILL_SHARD->"kill-shard";};
        String cfgPath="boosters."+typeKey+"."+(server?"server":"personal")+".price-"+dKey;
        int base=switch(type){case MINING_3X3->100;case MULTI_BLOCK->150;case NUKER->200;case KILL_SHARD->200;};
        int mult=server?5:1;int[]mults={1,2,5,15};int idx=switch(dKey){case"5m"->0;case"10m"->1;case"30m"->2;default->3;};
        int price=plugin.getBoosterConfig().getInt(cfgPath,base*mult*mults[idx]);
        PlayerPointsAPI pp=plugin.getPlayerPointsAPI();
        if(pp==null){player.sendMessage("§c[SchoolMine] PlayerPoints không khả dụng!");player.closeInventory();return;}
        int balance=pp.look(player.getUniqueId());
        if(balance<price){player.sendMessage("§c[SchoolMine] Không đủ điểm! Cần §e"+price+"§c, bạn có §e"+balance+"§c.");player.closeInventory();return;}
        if(!pp.take(player.getUniqueId(),price)){player.sendMessage("§c[SchoolMine] Giao dịch thất bại!");player.closeInventory();return;}
        String typeName=switch(type){case MINING_3X3->"3x3 Mining";case MULTI_BLOCK->"x2 Block";case NUKER->"Nuker";case KILL_SHARD->"Kill Shard";};
        BoosterManager bm=plugin.getBoosterManager();
        if(server){bm.activateServerBooster(player,type,durationMs);for(Player p:Bukkit.getOnlinePlayers())p.sendMessage("§6[SchoolMine] §e"+player.getName()+" §đã kích hoạt §a"+typeName+" Server Booster! §7(§e"+BoosterManager.formatTime(durationMs)+"§7)");}
        else{bm.activatePlayerBooster(player,type,durationMs);player.sendMessage("§a[SchoolMine] Kích hoạt §e"+typeName+"§a thành công! (§e"+BoosterManager.formatTime(durationMs)+"§a)");}
        player.closeInventory();}
}
