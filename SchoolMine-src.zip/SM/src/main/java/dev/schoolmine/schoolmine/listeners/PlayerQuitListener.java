package dev.schoolmine.schoolmine.listeners;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerQuitEvent;
public class PlayerQuitListener implements Listener{
    private final SchoolMine plugin;
    public PlayerQuitListener(SchoolMine p){plugin=p;}
    @EventHandler public void onQuit(PlayerQuitEvent e){plugin.getPlayerDataManager().unload(e.getPlayer().getUniqueId());plugin.getBoosterManager().onPlayerQuit(e.getPlayer());}
}
