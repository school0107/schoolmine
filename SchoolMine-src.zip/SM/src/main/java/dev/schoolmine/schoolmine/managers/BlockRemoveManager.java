package dev.schoolmine.schoolmine.managers;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.*;
import java.util.*;
public class BlockRemoveManager {
    private final SchoolMine plugin; private final File dataFile;
    private final TreeMap<Long,List<String>> removeQueue=new TreeMap<>();
    private boolean enabled; private long delayMs; private Set<Material> blacklist;
    private Set<String> worldWhitelist; private boolean worldWhitelistEnabled;
    private int maxQueueSize,checkIntervalTicks; private boolean persist;
    private int totalQueued=0,schedulerTaskId=-1;
    public BlockRemoveManager(SchoolMine p){plugin=p;dataFile=new File(p.getDataFolder(),"blockremove_queue.yml");reload();if(persist)loadFromDisk();startScheduler();}
    public void reload(){
        var cfg=plugin.getConfig();
        enabled=cfg.getBoolean("block-remove.enabled",true);delayMs=(long)cfg.getInt("block-remove.delay-seconds",120)*1000L;
        maxQueueSize=cfg.getInt("block-remove.max-queue-size",100000);checkIntervalTicks=Math.max(1,cfg.getInt("block-remove.check-interval-ticks",40));
        persist=cfg.getBoolean("block-remove.persist-on-restart",true);
        blacklist=EnumSet.noneOf(Material.class);
        for(String s:cfg.getStringList("block-remove.blacklist")){Material m=Material.matchMaterial(s);if(m!=null)blacklist.add(m);}
        worldWhitelist=new HashSet<>();List<String> wl=cfg.getStringList("block-remove.world-whitelist");worldWhitelistEnabled=!wl.isEmpty();worldWhitelist.addAll(wl);
        if(schedulerTaskId!=-1){Bukkit.getScheduler().cancelTask(schedulerTaskId);schedulerTaskId=-1;}
        if(enabled)startScheduler();
    }
    public boolean shouldTrack(Location loc){if(!enabled)return false;if(worldWhitelistEnabled){World w=loc.getWorld();if(w==null||!worldWhitelist.contains(w.getName()))return false;}return true;}
    public boolean isBlacklisted(Material m){return blacklist.contains(m);}
    public void queueBlock(Location loc){if(totalQueued>=maxQueueSize)return;long e=System.currentTimeMillis()+delayMs;removeQueue.computeIfAbsent(e,k->new ArrayList<>()).add(ser(loc));totalQueued++;}
    private void startScheduler(){if(!enabled)return;schedulerTaskId=Bukkit.getScheduler().runTaskTimer(plugin,this::tick,checkIntervalTicks,checkIntervalTicks).getTaskId();}
    private void tick(){if(removeQueue.isEmpty())return;long now=System.currentTimeMillis();int p=0;while(!removeQueue.isEmpty()&&p<200){Map.Entry<Long,List<String>> e=removeQueue.firstEntry();if(e.getKey()>now)break;removeQueue.pollFirstEntry();for(String s:e.getValue()){Location l=deser(s);totalQueued--;if(l==null)continue;World w=l.getWorld();if(w==null)continue;Block b=w.getBlockAt(l);if(!b.getType().isAir())b.setType(Material.AIR,false);p++;}}}
    public void saveToDisk(){if(!persist||removeQueue.isEmpty())return;YamlConfiguration y=new YamlConfiguration();List<String> es=new ArrayList<>();long now=System.currentTimeMillis();for(var e:removeQueue.entrySet()){long r=e.getKey()-now;if(r<=0)continue;for(String l:e.getValue())es.add(r+":"+l);}y.set("entries",es);try{y.save(dataFile);}catch(IOException ex){plugin.getLogger().warning("Failed to save decay queue");}}
    private void loadFromDisk(){if(!dataFile.exists())return;YamlConfiguration y=YamlConfiguration.loadConfiguration(dataFile);long now=System.currentTimeMillis();int loaded=0;for(String e:y.getStringList("entries")){int c=e.indexOf(':');if(c<0)continue;try{long r=Long.parseLong(e.substring(0,c));String l=e.substring(c+1);removeQueue.computeIfAbsent(now+r,k->new ArrayList<>()).add(l);totalQueued++;loaded++;if(totalQueued>=maxQueueSize)break;}catch(NumberFormatException ignored){}}if(loaded>0)plugin.getLogger().info("[BlockRemove] Loaded "+loaded+" pending blocks.");dataFile.delete();}
    public void shutdown(){if(schedulerTaskId!=-1)Bukkit.getScheduler().cancelTask(schedulerTaskId);saveToDisk();}
    public int getQueueSize(){return totalQueued;} public boolean isEnabled(){return enabled;}
    private static String ser(Location l){return l.getWorld().getName()+","+l.getBlockX()+","+l.getBlockY()+","+l.getBlockZ();}
    private Location deser(String s){String[] p=s.split(",");if(p.length!=4)return null;try{World w=Bukkit.getWorld(p[0]);if(w==null)return null;return new Location(w,Integer.parseInt(p[1]),Integer.parseInt(p[2]),Integer.parseInt(p[3]));}catch(NumberFormatException e){return null;}}
}
