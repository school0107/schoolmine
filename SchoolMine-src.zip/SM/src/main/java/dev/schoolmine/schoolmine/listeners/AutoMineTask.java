package dev.schoolmine.schoolmine.listeners;

import dev.schoolmine.schoolmine.SchoolMine;
import dev.schoolmine.schoolmine.managers.ConfigManager;
import dev.schoolmine.schoolmine.managers.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.*;

public class AutoMineTask implements Runnable {

    private final SchoolMine plugin;
    // Per-player: remaining ticks until next mine cycle
    private final Map<UUID, Integer> cooldowns = new HashMap<>();
    private int taskId = -1;

    public AutoMineTask(SchoolMine p) { plugin = p; }

    public void start() {
        taskId = Bukkit.getScheduler().runTaskTimer(plugin, this, 1L, 1L).getTaskId();
    }

    public void stop() {
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
    }

    @Override
    public void run() {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.isConfigurationSection("auto-mine")) return;

        int baseInterval = Math.max(1, cfg.getInt("auto-mine.base-interval-ticks", 20));
        int maxBlocks = cfg.getInt("auto-mine.max-blocks-per-tick", 20);
        boolean onlyAboveFeet = cfg.getBoolean("auto-mine.only-above-feet", true);
        boolean requirePickaxe = cfg.getBoolean("auto-mine.require-pickaxe", true);
        double effBonus = cfg.getDouble("auto-mine.efficiency-bonus-per-level", 0.4);
        boolean applyFortune = cfg.getBoolean("auto-mine.apply-fortune", true);
        boolean applySilkTouch = cfg.getBoolean("auto-mine.apply-silk-touch", true);

        Set<Material> whitelist = EnumSet.noneOf(Material.class);
        for (String s : cfg.getStringList("auto-mine.whitelist")) {
            Material m = Material.matchMaterial(s);
            if (m != null) whitelist.add(m);
        }
        if (whitelist.isEmpty()) return;

        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (!data.isAutoMine()) { cooldowns.remove(uuid); continue; }

            ItemStack tool = player.getInventory().getItemInMainHand();
            if (requirePickaxe && !isPickaxe(tool)) { cooldowns.remove(uuid); continue; }

            // Radius from permission automine.1..6, fallback to config
            int radius = getAutoMineRadius(player, cfg.getInt("auto-mine.radius", 3));

            int interval = calcInterval(tool, baseInterval, effBonus, cfg);
            int cd = cooldowns.getOrDefault(uuid, 0);
            if (cd > 0) { cooldowns.put(uuid, cd - 1); continue; }
            cooldowns.put(uuid, interval - 1);

            mine(player, tool, radius, onlyAboveFeet, whitelist, maxBlocks,
                 applyFortune, applySilkTouch, cfg);
        }
    }

    /**
     * Radius từ permission automine.1 đến automine.6
     * Nếu không có permission cụ thể, dùng fallback từ config
     */
    private int getAutoMineRadius(Player player, int fallback) {
        for (int r = 6; r >= 1; r--) {
            if (player.hasPermission("automine." + r)) return r;
        }
        return fallback;
    }

    /**
     * Drop multiplier từ permission mine.x1.2, mine.x1.4, mine.x1.6, mine.x1.8, mine.x2 ... mine.x5
     * Trả về float multiplier (1.0 = bình thường)
     */
    public static double getDropMultiplier(Player player) {
        // Check integer multipliers x2..x5 (higher first)
        for (int i = 5; i >= 2; i--) {
            if (player.hasPermission("mine.x" + i)) return i;
        }
        // Check decimal multipliers x1.2, x1.4, x1.6, x1.8
        double[] decimals = {1.8, 1.6, 1.4, 1.2};
        for (double d : decimals) {
            String perm = "mine.x" + String.valueOf(d).replace(".0", "");
            if (player.hasPermission(perm)) return d;
        }
        return 1.0;
    }

    private int calcInterval(ItemStack tool, int base, double effBonus, FileConfiguration cfg) {
        if (tool == null || tool.getType().isAir()) return base;
        double speed = cfg.getDouble("auto-mine.tool-speed." + tool.getType().name(), 1.0);
        int eff = tool.getEnchantmentLevel(Enchantment.EFFICIENCY);
        speed += eff * effBonus;
        if (speed <= 0) speed = 0.1;
        return (int) Math.max(1, base / speed);
    }

    private void mine(Player player, ItemStack tool, int radius, boolean onlyAboveFeet,
                      Set<Material> whitelist, int maxBlocks, boolean applyFortune,
                      boolean applySilkTouch, FileConfiguration cfg) {
        Location center = player.getLocation();
        World world = center.getWorld();
        if (world == null) return;

        ConfigManager cm = plugin.getConfigManager();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        boolean doSmelt = cfg.getBoolean("auto-mine.apply-autosmelt", true)
            && player.hasPermission("schoolmine.autosmelt") && data.isAutoSmelt();
        boolean doPickup = cfg.getBoolean("auto-mine.apply-autopickup", true) && data.isAutoPickup();

        double dropMult = getDropMultiplier(player);
        boolean hasSilk = applySilkTouch && tool != null && tool.getEnchantmentLevel(Enchantment.SILK_TOUCH) > 0;
        int fortune = (applyFortune && tool != null) ? tool.getEnchantmentLevel(Enchantment.FORTUNE) : 0;

        int cx = center.getBlockX(), cy = center.getBlockY(), cz = center.getBlockZ();
        int radSq = radius * radius, dyMin = onlyAboveFeet ? 0 : -radius, mined = 0;

        for (int dx = -radius; dx <= radius && mined < maxBlocks; dx++)
            for (int dy = dyMin; dy <= radius && mined < maxBlocks; dy++)
                for (int dz = -radius; dz <= radius && mined < maxBlocks; dz++) {
                    if (dx*dx + dy*dy + dz*dz > radSq) continue;
                    Block block = world.getBlockAt(cx+dx, cy+dy, cz+dz);
                    Material type = block.getType();
                    if (type.isAir() || type.name().equals("BEDROCK") || !whitelist.contains(type)) continue;

                    Collection<ItemStack> drops = buildDrops(block, tool, type, hasSilk, fortune, dropMult, doSmelt, cm);
                    if (doPickup && !cm.getAutopickupBlacklist().contains(type)) {
                        giveItems(player, block, drops);
                    } else {
                        for (ItemStack drop : drops)
                            block.getWorld().dropItemNaturally(block.getLocation(), drop);
                    }
                    block.setType(Material.AIR, false);
                    mined++;
                }
    }

    private Collection<ItemStack> buildDrops(Block block, ItemStack tool, Material type,
                                              boolean silkTouch, int fortune, double dropMult,
                                              boolean doSmelt, ConfigManager cm) {
        if (silkTouch) {
            int amt = (int) Math.max(1, Math.round(dropMult));
            return Collections.singletonList(new ItemStack(type, amt));
        }

        Collection<ItemStack> raw = block.getDrops(tool, null);
        List<ItemStack> result = new ArrayList<>();
        Random rng = new Random();

        for (ItemStack drop : raw) {
            if (drop == null || drop.getType().isAir()) continue;
            int amount = drop.getAmount();

            // Fortune bonus
            if (fortune > 0) {
                int roll = rng.nextInt(fortune + 2);
                if (roll > 1) amount *= roll;
            }

            // Drop multiplier from permission
            if (dropMult != 1.0) {
                amount = (int) Math.max(1, Math.round(amount * dropMult));
            }

            // AutoSmelt
            if (doSmelt) {
                Material smelt = cm.getSmeltResult(type);
                if (smelt == null) smelt = cm.getSmeltResult(drop.getType());
                if (smelt != null) { result.add(new ItemStack(smelt, amount)); continue; }
            }
            result.add(new ItemStack(drop.getType(), amount));
        }
        return result;
    }

    private void giveItems(Player player, Block block, Collection<ItemStack> drops) {
        PlayerInventory inv = player.getInventory();
        for (ItemStack drop : drops) {
            if (drop == null || drop.getType().isAir()) continue;
            HashMap<Integer, ItemStack> left = inv.addItem(drop.clone());
            if (!left.isEmpty())
                for (ItemStack l : left.values())
                    block.getWorld().dropItemNaturally(block.getLocation(), l);
        }
    }

    private boolean isPickaxe(ItemStack item) {
        return item != null && item.getType().name().endsWith("_PICKAXE");
    }
}
