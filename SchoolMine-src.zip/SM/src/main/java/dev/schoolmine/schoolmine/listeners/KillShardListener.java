package dev.schoolmine.schoolmine.listeners;
import dev.schoolmine.schoolmine.SchoolMine;
import dev.schoolmine.schoolmine.managers.BoosterManager.BoosterType;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.entity.PlayerDeathEvent;
import java.util.List;
public class KillShardListener implements Listener{
    private final SchoolMine plugin;
    public KillShardListener(SchoolMine p){plugin=p;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onPlayerDeath(PlayerDeathEvent event){
        Player victim=event.getEntity();Player killer=victim.getKiller();if(killer==null)return;
        if(!plugin.getBoosterManager().hasBooster(killer.getUniqueId(),BoosterType.KILL_SHARD))return;
        var cfg=plugin.getBoosterConfig();List<String> cmds=cfg.getStringList("kill-shard.commands");
        String msg=cfg.getString("kill-shard.message","&a+Shard!");
        for(String cmd:cmds)Bukkit.dispatchCommand(Bukkit.getConsoleSender(),cmd.replace("{player}",killer.getName()).replace("{victim}",victim.getName()));
        killer.sendMessage(msg.replace("{player}",killer.getName()).replace("{victim}",victim.getName()).replace("&","\u00A7"));}
}
