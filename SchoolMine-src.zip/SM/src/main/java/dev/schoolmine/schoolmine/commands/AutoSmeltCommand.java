package dev.schoolmine.schoolmine.commands;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;
public class AutoSmeltCommand implements CommandExecutor,TabCompleter{
    private final SchoolMine plugin;
    public AutoSmeltCommand(SchoolMine p){plugin=p;}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(!(sender instanceof Player player)){sender.sendMessage("§cOnly players!");return true;}
        if(!player.hasPermission("schoolmine.autosmelt")){player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));return true;}
        var data=plugin.getPlayerDataManager().get(player);
        boolean n=args.length==0?!data.isAutoSmelt():args[0].equalsIgnoreCase("on");
        if(args.length>0&&!args[0].equalsIgnoreCase("on")&&!args[0].equalsIgnoreCase("off")){player.sendMessage(plugin.getConfigManager().getMessage("usage-autosmelt"));return true;}
        data.setAutoSmelt(n);player.sendMessage(plugin.getConfigManager().getMessage(n?"autosmelt-on":"autosmelt-off"));return true;}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String l,String[] a){return a.length==1?Arrays.asList("on","off"):List.of();}
}
