package dev.schoolmine.schoolmine.managers;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public class PlayerDataManager {
    private final SchoolMine plugin;
    private final File dataFolder;
    private final ConcurrentHashMap<UUID,PlayerData> cache = new ConcurrentHashMap<>();
    public PlayerDataManager(SchoolMine p){plugin=p;dataFolder=new File(p.getDataFolder(),"playerdata");dataFolder.mkdirs();}
    public PlayerData get(Player p){return cache.computeIfAbsent(p.getUniqueId(),this::load);}
    public PlayerData get(UUID uuid){return cache.computeIfAbsent(uuid,this::load);}
    private PlayerData load(UUID uuid){
        File f=new File(dataFolder,uuid+".yml");
        ConfigManager cm=plugin.getConfigManager();
        if(!f.exists())return new PlayerData(uuid,cm.isAutopickupDefaultEnabled(),cm.isMining3x3DefaultEnabled(),cm.isAutosmeltDefaultEnabled(),false);
        try{YamlConfiguration y=YamlConfiguration.loadConfiguration(f);
            return new PlayerData(uuid,y.getBoolean("autopickup",cm.isAutopickupDefaultEnabled()),y.getBoolean("mining3x3",cm.isMining3x3DefaultEnabled()),y.getBoolean("autosmelt",cm.isAutosmeltDefaultEnabled()),y.getBoolean("automine",false));
        }catch(Exception e){return new PlayerData(uuid,cm.isAutopickupDefaultEnabled(),cm.isMining3x3DefaultEnabled(),cm.isAutosmeltDefaultEnabled(),false);}
    }
    public void save(UUID uuid){
        PlayerData d=cache.get(uuid);if(d==null)return;
        File f=new File(dataFolder,uuid+".yml");f.getParentFile().mkdirs();
        YamlConfiguration y=new YamlConfiguration();
        y.set("autopickup",d.isAutoPickup());y.set("mining3x3",d.isMining3x3());y.set("autosmelt",d.isAutoSmelt());y.set("automine",d.isAutoMine());
        try{y.save(f);}catch(IOException e){plugin.getLogger().warning("Failed to save "+uuid);}
    }
    public void saveAll(){cache.keySet().forEach(this::save);}
    public void clearCache(){cache.clear();}
    public void unload(UUID uuid){save(uuid);cache.remove(uuid);}
}
