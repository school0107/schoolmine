package dev.schoolmine.schoolmine.managers;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.Bukkit;
import org.bukkit.boss.*;
import org.bukkit.entity.Player;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public class BoosterManager {
    public enum BoosterType{MINING_3X3,MULTI_BLOCK,NUKER,KILL_SHARD}
    public static class BoosterData{
        public final UUID owner; public final BoosterType type; public long expiresAt; public BossBar bossBar;
        public BoosterData(UUID owner,BoosterType type,long expiresAt){this.owner=owner;this.type=type;this.expiresAt=expiresAt;}
        public boolean isExpired(){return System.currentTimeMillis()>=expiresAt;}
        public long remainingMs(){return Math.max(0,expiresAt-System.currentTimeMillis());}
        public boolean isServer(){return owner==null;}
    }
    private final SchoolMine plugin;
    private final ConcurrentHashMap<UUID,Map<BoosterType,BoosterData>> playerBoosters=new ConcurrentHashMap<>();
    private final ConcurrentHashMap<BoosterType,BoosterData> serverBoosters=new ConcurrentHashMap<>();
    private int tickTaskId=-1;
    public BoosterManager(SchoolMine p){plugin=p;startTicker();}
    public void activatePlayerBooster(Player player,BoosterType type,long durationMs){
        Map<BoosterType,BoosterData> map=playerBoosters.computeIfAbsent(player.getUniqueId(),k->new ConcurrentHashMap<>());
        BoosterData ex=map.get(type);
        if(ex!=null&&!ex.isExpired()){ex.expiresAt+=durationMs;updateBossBarProgress(ex);}
        else{long expiry=System.currentTimeMillis()+durationMs;BoosterData d=new BoosterData(player.getUniqueId(),type,expiry);d.bossBar=createBossBar(type,false);d.bossBar.addPlayer(player);map.put(type,d);updateBossBarProgress(d);}
    }
    public void activateServerBooster(Player activator,BoosterType type,long durationMs){
        BoosterData ex=serverBoosters.get(type);
        if(ex!=null&&!ex.isExpired()){ex.expiresAt+=durationMs;}
        else{long expiry=System.currentTimeMillis()+durationMs;BoosterData d=new BoosterData(null,type,expiry);d.bossBar=createBossBar(type,true);for(Player p:Bukkit.getOnlinePlayers())d.bossBar.addPlayer(p);serverBoosters.put(type,d);}
        broadcastServerBoosterTitle(activator,type,durationMs);
    }
    private void broadcastServerBoosterTitle(Player activator,BoosterType type,long durationMs){
        var cfg=plugin.getBoosterConfig();
        if(!cfg.getBoolean("server-booster-title.enabled",true))return;
        String typeName=typeName(type);
        String title=colorize(cfg.getString("server-booster-title.title","&6&l⚡ SERVER BOOSTER ⚡"));
        String subtitle=colorize(cfg.getString("server-booster-title.subtitle","&e{player} &7kích hoạt &a{type}!").replace("{player}",activator.getName()).replace("{type}",typeName).replace("{duration}",formatTime(durationMs)));
        int fi=cfg.getInt("server-booster-title.fade-in",10),st=cfg.getInt("server-booster-title.stay",60),fo=cfg.getInt("server-booster-title.fade-out",10);
        for(Player p:Bukkit.getOnlinePlayers())p.sendTitle(title,subtitle,fi,st,fo);
    }
    public void onPlayerJoin(Player p){for(BoosterData d:serverBoosters.values())if(!d.isExpired())d.bossBar.addPlayer(p);Map<BoosterType,BoosterData> m=playerBoosters.get(p.getUniqueId());if(m!=null)for(BoosterData d:m.values())if(!d.isExpired())d.bossBar.addPlayer(p);}
    public void onPlayerQuit(Player p){Map<BoosterType,BoosterData> m=playerBoosters.get(p.getUniqueId());if(m!=null)for(BoosterData d:m.values())if(d.bossBar!=null)d.bossBar.removePlayer(p);}
    public boolean hasBooster(UUID uuid,BoosterType type){BoosterData s=serverBoosters.get(type);if(s!=null&&!s.isExpired())return true;Map<BoosterType,BoosterData> m=playerBoosters.get(uuid);if(m==null)return false;BoosterData d=m.get(type);return d!=null&&!d.isExpired();}
    public BoosterData getPlayerBooster(UUID uuid,BoosterType type){Map<BoosterType,BoosterData> m=playerBoosters.get(uuid);if(m==null)return null;BoosterData d=m.get(type);return(d!=null&&!d.isExpired())?d:null;}
    public BoosterData getServerBooster(BoosterType type){BoosterData d=serverBoosters.get(type);return(d!=null&&!d.isExpired())?d:null;}
    public void removePlayerBooster(UUID uuid,BoosterType type){Map<BoosterType,BoosterData> m=playerBoosters.get(uuid);if(m==null)return;BoosterData d=m.remove(type);if(d!=null&&d.bossBar!=null)d.bossBar.removeAll();}
    public void removeServerBooster(BoosterType type){BoosterData d=serverBoosters.remove(type);if(d!=null&&d.bossBar!=null)d.bossBar.removeAll();}
    public void removeAllBoosters(UUID uuid){for(BoosterType t:BoosterType.values())removePlayerBooster(uuid,t);}
    public void removeAllServerBoosters(){for(BoosterType t:BoosterType.values())removeServerBooster(t);}
    private void startTicker(){tickTaskId=Bukkit.getScheduler().runTaskTimer(plugin,this::tick,20L,20L).getTaskId();}
    private void tick(){long now=System.currentTimeMillis();
        for(var e:serverBoosters.entrySet()){BoosterData d=e.getValue();if(d.isExpired()){if(d.bossBar!=null)d.bossBar.removeAll();serverBoosters.remove(e.getKey());}else updateBossBarProgress(d);}
        for(var pe:playerBoosters.entrySet()){UUID uuid=pe.getKey();Player p=Bukkit.getOnlinePlayers().stream().filter(pl->pl.getUniqueId().equals(uuid)).findFirst().orElse(null);
            for(var be:pe.getValue().entrySet()){BoosterData d=be.getValue();if(d.isExpired()){if(d.bossBar!=null)d.bossBar.removeAll();pe.getValue().remove(be.getKey());}else if(p!=null)updateBossBarProgress(d);}}}
    private void updateBossBarProgress(BoosterData data){if(data.bossBar==null)return;long r=data.remainingMs();data.bossBar.setTitle("§6"+(data.isServer()?"[SERVER] ":"")+bossBarLabel(data.type)+" §7- §e"+formatTime(r));data.bossBar.setProgress(Math.max(0.0,Math.min(1.0,r/(double)(2*60*60*1000))));}
    private String bossBarLabel(BoosterType t){return switch(t){case MINING_3X3->"⛏ 3x3";case MULTI_BLOCK->"✦ x2 Block";case NUKER->"☢ Nuker";case KILL_SHARD->"⚔ Kill Shard";};}
    private String typeName(BoosterType t){return switch(t){case MINING_3X3->"3x3 Mining";case MULTI_BLOCK->"x2 Block";case NUKER->"Nuker";case KILL_SHARD->"Kill Shard";};}
    private BossBar createBossBar(BoosterType type,boolean server){
        String title=(server?"[SERVER] ":"")+switch(type){case MINING_3X3->"⛏ 3x3 Mining Booster";case MULTI_BLOCK->"✦ x2 Block Booster";case NUKER->"☢ Nuker Booster";case KILL_SHARD->"⚔ Kill Shard Booster";};
        BarColor color=switch(type){case MINING_3X3->BarColor.YELLOW;case MULTI_BLOCK->BarColor.GREEN;case NUKER->BarColor.RED;case KILL_SHARD->BarColor.PURPLE;};
        return Bukkit.createBossBar(title,color,BarStyle.SEGMENTED_10);
    }
    public static String formatTime(long ms){long s=ms/1000;if(s<60)return s+"s";long m=s/60;if(m<60)return m+"m "+(s%60)+"s";long h=m/60;return h+"h "+(m%60)+"m";}
    private String colorize(String s){return s==null?"":s.replace("&","\u00A7");}
    public void shutdown(){if(tickTaskId!=-1)Bukkit.getScheduler().cancelTask(tickTaskId);for(BoosterData d:serverBoosters.values())if(d.bossBar!=null)d.bossBar.removeAll();for(var m:playerBoosters.values())for(BoosterData d:m.values())if(d.bossBar!=null)d.bossBar.removeAll();}
}
