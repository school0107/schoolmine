package dev.schoolmine.schoolmine.managers;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import java.util.*;
public class ConfigManager {
    private final SchoolMine plugin;
    private boolean autopickupDefaultEnabled; private Set<Material> autopickupBlacklist;
    private boolean mining3x3DefaultEnabled; private Set<Material> mining3x3Whitelist; private boolean mining3x3RequireCorrectTool; private int mining3x3Radius;
    private boolean autosmeltDefaultEnabled; private Map<Material,Material> smeltMap;
    private int autoSaveInterval; private int max3x3Blocks;
    private String prefix; private Map<String,String> messages;
    public ConfigManager(SchoolMine p){plugin=p;load();}
    public void reload(){load();}
    private void load(){
        FileConfiguration cfg=plugin.getConfig();
        autopickupDefaultEnabled=cfg.getBoolean("auto-pickup.default-enabled",true);
        autopickupBlacklist=loadMats(cfg,"auto-pickup.blacklist");
        mining3x3DefaultEnabled=cfg.getBoolean("3x3-mining.default-enabled",false);
        mining3x3Whitelist=loadMats(cfg,"3x3-mining.whitelist");
        mining3x3RequireCorrectTool=cfg.getBoolean("3x3-mining.require-correct-tool",true);
        mining3x3Radius=Math.max(1,Math.min(cfg.getInt("3x3-mining.radius",1),3));
        autosmeltDefaultEnabled=cfg.getBoolean("auto-smelt.default-enabled",false);
        smeltMap=new EnumMap<>(Material.class);
        ConfigurationSection ss=cfg.getConfigurationSection("auto-smelt.smelt-map");
        if(ss!=null)for(String k:ss.getKeys(false)){Material f=Material.matchMaterial(k),t=Material.matchMaterial(ss.getString(k,""));if(f!=null&&t!=null)smeltMap.put(f,t);}
        autoSaveInterval=cfg.getInt("performance.auto-save-interval",300);
        max3x3Blocks=Math.max(1,Math.min(cfg.getInt("performance.max-3x3-blocks",27),27));
        messages=new HashMap<>();prefix=cfg.getString("messages.prefix","&8[&6SchoolMine&8] &r");
        ConfigurationSection ms=cfg.getConfigurationSection("messages");
        if(ms!=null)for(String k:ms.getKeys(false))messages.put(k,ms.getString(k,""));
    }
    private Set<Material> loadMats(FileConfiguration cfg,String path){
        Set<Material> s=EnumSet.noneOf(Material.class);
        for(String m:cfg.getStringList(path)){Material mat=Material.matchMaterial(m);if(mat!=null)s.add(mat);}
        return s;
    }
    public String getMessage(String key){return colorize(prefix+messages.getOrDefault(key,"&cMessage not found: "+key));}
    private String colorize(String s){return s==null?"":s.replace("&","\u00A7");}
    public boolean isAutopickupDefaultEnabled(){return autopickupDefaultEnabled;}
    public Set<Material> getAutopickupBlacklist(){return autopickupBlacklist;}
    public boolean isMining3x3DefaultEnabled(){return mining3x3DefaultEnabled;}
    public Set<Material> getMining3x3Whitelist(){return mining3x3Whitelist;}
    public boolean isMining3x3RequireCorrectTool(){return mining3x3RequireCorrectTool;}
    public int getMining3x3Radius(){return mining3x3Radius;}
    public boolean isAutosmeltDefaultEnabled(){return autosmeltDefaultEnabled;}
    public Map<Material,Material> getSmeltMap(){return smeltMap;}
    public Material getSmeltResult(Material m){return smeltMap.get(m);}
    public int getAutoSaveInterval(){return autoSaveInterval;}
    public int getMax3x3Blocks(){return max3x3Blocks;}
}
