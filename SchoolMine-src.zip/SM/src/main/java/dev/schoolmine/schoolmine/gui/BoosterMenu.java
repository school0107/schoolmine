package dev.schoolmine.schoolmine.gui;
import dev.schoolmine.schoolmine.SchoolMine;
import dev.schoolmine.schoolmine.managers.BoosterManager;
import dev.schoolmine.schoolmine.managers.BoosterManager.BoosterType;
import dev.schoolmine.schoolmine.managers.BoosterManager.BoosterData;
import org.black_ixx.playerpoints.PlayerPointsAPI;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.*;
public class BoosterMenu implements InventoryHolder {
    public enum MenuPage{MAIN,PERSONAL_3X3,SERVER_3X3,PERSONAL_MULTI,SERVER_MULTI,PERSONAL_NUKER,SERVER_NUKER,PERSONAL_KILL_SHARD,SERVER_KILL_SHARD}
    private final SchoolMine plugin;private final Player player;private final MenuPage page;private Inventory inv;
    public BoosterMenu(SchoolMine p,Player pl,MenuPage pg){plugin=p;player=pl;page=pg;}
    public Inventory build(){switch(page){case MAIN->buildMain();case PERSONAL_3X3->buildPurchase(BoosterType.MINING_3X3,false);case SERVER_3X3->buildPurchase(BoosterType.MINING_3X3,true);case PERSONAL_MULTI->buildPurchase(BoosterType.MULTI_BLOCK,false);case SERVER_MULTI->buildPurchase(BoosterType.MULTI_BLOCK,true);case PERSONAL_NUKER->buildPurchase(BoosterType.NUKER,false);case SERVER_NUKER->buildPurchase(BoosterType.NUKER,true);case PERSONAL_KILL_SHARD->buildPurchase(BoosterType.KILL_SHARD,false);case SERVER_KILL_SHARD->buildPurchase(BoosterType.KILL_SHARD,true);}return inv;}
    private YamlConfiguration cfg(){return plugin.getBoosterConfig();}
    private void buildMain(){
        var cfg=cfg();inv=Bukkit.createInventory(this,54,c(cfg.getString("gui.main-title","&8&l⚡ Booster Menu")));
        fillBorder(inv,mat(cfg.getString("gui.border-material","GRAY_STAINED_GLASS_PANE")));
        var bm=plugin.getBoosterManager();PlayerPointsAPI pp=plugin.getPlayerPointsAPI();int balance=pp!=null?pp.look(player.getUniqueId()):0;
        inv.setItem(4,item(cfg,"gui.balance-item",Material.SUNFLOWER,ph("balance",""+balance)));
        inv.setItem(19,item(cfg,"gui.mining-3x3-personal",Material.DIAMOND_PICKAXE,ph("status",status(cfg,bm.getPlayerBooster(player.getUniqueId(),BoosterType.MINING_3X3)))));
        inv.setItem(21,item(cfg,"gui.mining-3x3-server",Material.NETHERITE_PICKAXE,ph("status",status(cfg,bm.getServerBooster(BoosterType.MINING_3X3)))));
        inv.setItem(23,item(cfg,"gui.multi-block-personal",Material.EMERALD,ph("status",status(cfg,bm.getPlayerBooster(player.getUniqueId(),BoosterType.MULTI_BLOCK)))));
        inv.setItem(25,item(cfg,"gui.multi-block-server",Material.EMERALD_BLOCK,ph("status",status(cfg,bm.getServerBooster(BoosterType.MULTI_BLOCK)))));
        inv.setItem(38,item(cfg,"gui.nuker-personal",Material.TNT,ph("status",status(cfg,bm.getPlayerBooster(player.getUniqueId(),BoosterType.NUKER)))));
        inv.setItem(40,item(cfg,"gui.nuker-server",Material.TNT_MINECART,ph("status",status(cfg,bm.getServerBooster(BoosterType.NUKER)))));
        inv.setItem(47,item(cfg,"gui.kill-shard-personal",Material.AMETHYST_SHARD,ph("status",status(cfg,bm.getPlayerBooster(player.getUniqueId(),BoosterType.KILL_SHARD)))));
        inv.setItem(51,item(cfg,"gui.kill-shard-server",Material.AMETHYST_CLUSTER,ph("status",status(cfg,bm.getServerBooster(BoosterType.KILL_SHARD)))));}
    private void buildPurchase(BoosterType type,boolean server){
        var cfg=cfg();String typeName=tname(type),scope=server?"Server":"Personal";
        inv=Bukkit.createInventory(this,54,c(cfg.getString("gui.purchase-title","&8&l⚡ {type} [{scope}]").replace("{type}",typeName).replace("{scope}",scope)));
        fillBorder(inv,mat(cfg.getString("gui.border-material","GRAY_STAINED_GLASS_PANE")));
        String base="boosters."+tkey(type)+"."+(server?"server":"personal");
        String[]dKeys={"5m","10m","30m","2h"};String[]dLabels={"5 Phút","10 Phút","30 Phút","2 Giờ"};int[]slots={20,22,24,31};int[]defPrices=defPrices(type,server);
        PlayerPointsAPI pp=plugin.getPlayerPointsAPI();int balance=pp!=null?pp.look(player.getUniqueId()):0;
        for(int i=0;i<4;i++){int price=cfg.getInt(base+".price-"+dKeys[i],defPrices[i]);boolean afford=balance>=price;
            String affordStr=afford?c(cfg.getString("gui.afford-yes","&aClick để mua")):c(cfg.getString("gui.afford-no","&cKhông đủ! (&e{balance}&c/&e{price}&c)").replace("{balance}",""+balance).replace("{price}",""+price));
            inv.setItem(slots[i],item(cfg,"gui.purchase-item",Material.CLOCK,ph("duration",dLabels[i],"type",typeName,"scope",scope,"price",""+price,"afford_status",affordStr)));}
        BoosterData active=server?plugin.getBoosterManager().getServerBooster(type):plugin.getBoosterManager().getPlayerBooster(player.getUniqueId(),type);
        inv.setItem(4,item(cfg,"gui.info-item",Material.PAPER,ph("type",typeName,"scope",scope,"status",status(cfg,active))));
        inv.setItem(49,item(cfg,"gui.back-button",Material.ARROW,new String[0][]));}
    private String status(YamlConfiguration cfg,BoosterData d){return d!=null?c(cfg.getString("gui.status-active","&aĐang: &e{time}").replace("{time}",BoosterManager.formatTime(d.remainingMs()))):c(cfg.getString("gui.status-inactive","&cChưa kích hoạt"));}
    private ItemStack item(YamlConfiguration cfg,String path,Material fallback,String[][]phs){
        String ms=cfg.getString(path+".material");Material mat=ms!=null?Material.matchMaterial(ms):null;if(mat==null)mat=fallback;
        String name=cfg.getString(path+".name"," ");List<String> loreRaw=cfg.getStringList(path+".lore");
        for(String[]ph:phs){name=name.replace("{"+ph[0]+"}",ph[1]);}name=c(name);
        List<String> lore=new ArrayList<>();for(String l:loreRaw){for(String[]ph:phs)l=l.replace("{"+ph[0]+"}",ph[1]);lore.add(c(l));}
        return make(mat,name,lore);}
    private String[][]ph(String...kv){List<String[]>l=new ArrayList<>();for(int i=0;i<kv.length;i+=2)l.add(new String[]{kv[i],kv[i+1]});return l.toArray(new String[0][]);}
    private int[]defPrices(BoosterType t,boolean server){int b=switch(t){case MINING_3X3->100;case MULTI_BLOCK->150;case NUKER->200;case KILL_SHARD->200;};int m=server?5:1;return new int[]{b*m,b*2*m,b*5*m,b*15*m};}
    private String tname(BoosterType t){return switch(t){case MINING_3X3->"3x3 Mining";case MULTI_BLOCK->"x2 Block";case NUKER->"Nuker";case KILL_SHARD->"Kill Shard";};}
    private String tkey(BoosterType t){return switch(t){case MINING_3X3->"mining-3x3";case MULTI_BLOCK->"multi-block";case NUKER->"nuker";case KILL_SHARD->"kill-shard";};}
    public long getDurationMsFromSlot(int slot){return switch(slot){case 20->5*60*1000L;case 22->10*60*1000L;case 24->30*60*1000L;case 31->2*60*60*1000L;default->-1L;};}
    public String getDurationKeyFromSlot(int slot){return switch(slot){case 20->"5m";case 22->"10m";case 24->"30m";case 31->"2h";default->null;};}
    public MenuPage getPage(){return page;}
    public BoosterType getTypeFromPage(){return switch(page){case PERSONAL_3X3,SERVER_3X3->BoosterType.MINING_3X3;case PERSONAL_NUKER,SERVER_NUKER->BoosterType.NUKER;case PERSONAL_KILL_SHARD,SERVER_KILL_SHARD->BoosterType.KILL_SHARD;default->BoosterType.MULTI_BLOCK;};}
    public boolean isServerPage(){return page==MenuPage.SERVER_3X3||page==MenuPage.SERVER_MULTI||page==MenuPage.SERVER_NUKER||page==MenuPage.SERVER_KILL_SHARD;}
    @Override public Inventory getInventory(){return inv;}
    private static String c(String s){return s==null?"":s.replace("&","\u00A7");}
    private static Material mat(String s){Material m=s!=null?Material.matchMaterial(s):null;return m!=null?m:Material.GRAY_STAINED_GLASS_PANE;}
    public static ItemStack make(Material mat,String name,List<String>lore){ItemStack i=new ItemStack(mat);ItemMeta m=i.getItemMeta();if(m!=null){m.setDisplayName(name);m.setLore(lore);i.setItemMeta(m);}return i;}
    public static void fillBorder(Inventory inv,Material mat){ItemStack g=make(mat," ",List.of());int size=inv.getSize(),rows=size/9;for(int i=0;i<9;i++)inv.setItem(i,g);for(int i=size-9;i<size;i++)inv.setItem(i,g);for(int r=1;r<rows-1;r++){inv.setItem(r*9,g);inv.setItem(r*9+8,g);}}
}
