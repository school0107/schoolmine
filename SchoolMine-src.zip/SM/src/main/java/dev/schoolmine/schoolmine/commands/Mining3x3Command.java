package dev.schoolmine.schoolmine.commands;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;
public class Mining3x3Command implements CommandExecutor,TabCompleter{
    private final SchoolMine plugin;
    public Mining3x3Command(SchoolMine p){plugin=p;}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(!(sender instanceof Player player)){sender.sendMessage("§cOnly players!");return true;}
        if(!player.hasPermission("schoolmine.3x3")){player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));return true;}
        var data=plugin.getPlayerDataManager().get(player);
        boolean n=args.length==0?!data.isMining3x3():args[0].equalsIgnoreCase("on");
        if(args.length>0&&!args[0].equalsIgnoreCase("on")&&!args[0].equalsIgnoreCase("off")){player.sendMessage(plugin.getConfigManager().getMessage("usage-3x3"));return true;}
        data.setMining3x3(n);player.sendMessage(plugin.getConfigManager().getMessage(n?"mining3x3-on":"mining3x3-off"));return true;}
    @Override public List<String> onTabComplete(CommandSender s,Command c,String l,String[] a){return a.length==1?Arrays.asList("on","off"):List.of();}
}
