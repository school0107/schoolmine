package dev.schoolmine.schoolmine.commands;
import dev.schoolmine.schoolmine.SchoolMine;
import dev.schoolmine.schoolmine.gui.BoosterMenu;
import dev.schoolmine.schoolmine.managers.BoosterManager;
import dev.schoolmine.schoolmine.managers.BoosterManager.BoosterType;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.*;
public class BoosterCommand implements CommandExecutor,TabCompleter{
    private final SchoolMine plugin;
    public BoosterCommand(SchoolMine p){plugin=p;}
    @Override public boolean onCommand(CommandSender sender,Command cmd,String label,String[] args){
        if(!(sender instanceof Player player)){if(args.length>=1&&args[0].equalsIgnoreCase("clearall")){plugin.getBoosterManager().removeAllServerBoosters();sender.sendMessage("[SchoolMine] Removed all server boosters.");}else sender.sendMessage("Use in-game or: /booster clearall");return true;}
        if(args.length==0){if(!player.hasPermission("schoolmine.booster")){player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));return true;}player.openInventory(new BoosterMenu(plugin,player,BoosterMenu.MenuPage.MAIN).build());return true;}
        switch(args[0].toLowerCase()){
            case"clear"->{if(!player.hasPermission("schoolmine.booster.admin")){player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));return true;}if(args.length<2){player.sendMessage("§cUsage: /booster clear <player|server> [type]");return true;}if(args[1].equalsIgnoreCase("server")){clearBoosters(player,null,args.length>=3?args[2]:"all");}else{Player t=Bukkit.getOnlinePlayers().stream().filter(p->p.getName().equalsIgnoreCase(args[1])).findFirst().orElse(null);if(t==null){player.sendMessage("§cPlayer not found.");return true;}clearBoosters(player,t,args.length>=3?args[2]:"all");}}
            case"clearall"->{if(!player.hasPermission("schoolmine.booster.admin")){player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));return true;}plugin.getBoosterManager().removeAllServerBoosters();for(Player p:Bukkit.getOnlinePlayers())plugin.getBoosterManager().removeAllBoosters(p.getUniqueId());player.sendMessage("§a[SchoolMine] Đã xóa toàn bộ booster.");}
            default->player.openInventory(new BoosterMenu(plugin,player,BoosterMenu.MenuPage.MAIN).build());}
        return true;}
    private void clearBoosters(Player admin,Player target,String typeArg){
        BoosterManager bm=plugin.getBoosterManager();
        if(target==null){switch(typeArg.toLowerCase()){case"3x3"->{bm.removeServerBooster(BoosterType.MINING_3X3);admin.sendMessage("§aXóa server 3x3.");}case"multi"->{bm.removeServerBooster(BoosterType.MULTI_BLOCK);admin.sendMessage("§aXóa server multi.");}case"nuker"->{bm.removeServerBooster(BoosterType.NUKER);admin.sendMessage("§aXóa server nuker.");}case"killshard"->{bm.removeServerBooster(BoosterType.KILL_SHARD);admin.sendMessage("§aXóa server killshard.");}default->{bm.removeAllServerBoosters();admin.sendMessage("§aXóa tất cả server booster.");}}}
        else{switch(typeArg.toLowerCase()){case"3x3"->{bm.removePlayerBooster(target.getUniqueId(),BoosterType.MINING_3X3);admin.sendMessage("§aXóa 3x3 của "+target.getName());}case"multi"->{bm.removePlayerBooster(target.getUniqueId(),BoosterType.MULTI_BLOCK);admin.sendMessage("§aXóa multi của "+target.getName());}case"nuker"->{bm.removePlayerBooster(target.getUniqueId(),BoosterType.NUKER);admin.sendMessage("§aXóa nuker của "+target.getName());}case"killshard"->{bm.removePlayerBooster(target.getUniqueId(),BoosterType.KILL_SHARD);admin.sendMessage("§aXóa killshard của "+target.getName());}default->{bm.removeAllBoosters(target.getUniqueId());admin.sendMessage("§aXóa tất cả booster của "+target.getName());}}}
    }
    @Override public List<String> onTabComplete(CommandSender s,Command c,String l,String[] a){if(a.length==1)return Arrays.asList("clear","clearall");if(a.length==2&&a[0].equalsIgnoreCase("clear"))return Arrays.asList("server","player");if(a.length==3&&a[0].equalsIgnoreCase("clear"))return Arrays.asList("3x3","multi","nuker","killshard","all");return List.of();}
}
