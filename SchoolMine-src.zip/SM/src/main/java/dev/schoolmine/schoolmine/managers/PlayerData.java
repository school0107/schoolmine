package dev.schoolmine.schoolmine.managers;
import java.util.UUID;
public class PlayerData {
    private final UUID uuid;
    private boolean autoPickup, mining3x3, autoSmelt, autoMine;
    public PlayerData(UUID uuid, boolean autoPickup, boolean mining3x3, boolean autoSmelt, boolean autoMine) {
        this.uuid=uuid; this.autoPickup=autoPickup; this.mining3x3=mining3x3; this.autoSmelt=autoSmelt; this.autoMine=autoMine;
    }
    public UUID getUuid(){return uuid;}
    public boolean isAutoPickup(){return autoPickup;} public void setAutoPickup(boolean v){autoPickup=v;}
    public boolean isMining3x3(){return mining3x3;} public void setMining3x3(boolean v){mining3x3=v;}
    public boolean isAutoSmelt(){return autoSmelt;} public void setAutoSmelt(boolean v){autoSmelt=v;}
    public boolean isAutoMine(){return autoMine;} public void setAutoMine(boolean v){autoMine=v;}
}
