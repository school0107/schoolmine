package dev.schoolmine.schoolmine.listeners;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockPlaceEvent;
public class BlockPlaceListener implements Listener{
    private final SchoolMine plugin;
    public BlockPlaceListener(SchoolMine p){plugin=p;}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true)
    public void onBlockPlace(BlockPlaceEvent event){
        if(!event.getPlayer().hasPermission("schoolmine.breakblock"))return;
        var rm=plugin.getBlockRemoveManager();var loc=event.getBlockPlaced().getLocation();
        if(!rm.shouldTrack(loc))return;if(rm.isBlacklisted(event.getBlockPlaced().getType()))return;rm.queueBlock(loc);}
}
