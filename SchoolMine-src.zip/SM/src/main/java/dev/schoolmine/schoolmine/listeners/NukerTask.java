package dev.schoolmine.schoolmine.listeners;
import dev.schoolmine.schoolmine.SchoolMine;
import dev.schoolmine.schoolmine.managers.BoosterManager.BoosterType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.util.*;
public class NukerTask implements Runnable {
    private final SchoolMine plugin;
    private final Map<UUID,Location> lastLoc=new HashMap<>();
    private int taskId=-1;
    public NukerTask(SchoolMine p){plugin=p;}
    public void start(){int interval=Math.max(1,boosterCfg().getInt("nuker.check-interval-ticks",15));taskId=Bukkit.getScheduler().runTaskTimer(plugin,this,interval,interval).getTaskId();}
    public void stop(){if(taskId!=-1)Bukkit.getScheduler().cancelTask(taskId);}
    private YamlConfiguration boosterCfg(){return plugin.getBoosterConfig();}
    @Override public void run(){
        var cfg=boosterCfg();
        int radius=cfg.getInt("nuker.radius",4);int max=cfg.getInt("nuker.max-blocks-per-check",25);
        boolean reqPick=cfg.getBoolean("nuker.require-pickaxe",true);boolean aboveFeet=cfg.getBoolean("nuker.only-above-feet",true);
        boolean applySmelt=cfg.getBoolean("nuker.apply-autosmelt",true);
        Set<Material> wl=EnumSet.noneOf(Material.class);for(String s:cfg.getStringList("nuker.whitelist")){Material m=Material.matchMaterial(s);if(m!=null)wl.add(m);}
        if(wl.isEmpty())return;
        for(Player p:Bukkit.getOnlinePlayers()){
            UUID uuid=p.getUniqueId();if(!plugin.getBoosterManager().hasBooster(uuid,BoosterType.NUKER)){lastLoc.remove(uuid);continue;}
            if(reqPick&&!p.getInventory().getItemInMainHand().getType().name().endsWith("_PICKAXE"))continue;
            Location cur=p.getLocation();Location last=lastLoc.get(uuid);
            if(last!=null&&sameBlock(last,cur))continue;lastLoc.put(uuid,cur.clone());
            mine(p,cur,radius,wl,max,aboveFeet,applySmelt);}
    }
    private void mine(Player player,Location center,int radius,Set<Material> wl,int max,boolean aboveFeet,boolean applySmelt){
        World world=center.getWorld();if(world==null)return;
        int cx=center.getBlockX(),cy=center.getBlockY(),cz=center.getBlockZ(),radSq=radius*radius,dyMin=aboveFeet?0:-radius,mined=0;
        ItemStack tool=player.getInventory().getItemInMainHand();
        boolean doSmelt=applySmelt&&player.hasPermission("schoolmine.autosmelt")&&plugin.getPlayerDataManager().get(player).isAutoSmelt();
        var cm=plugin.getConfigManager();
        for(int dx=-radius;dx<=radius&&mined<max;dx++)for(int dy=dyMin;dy<=radius&&mined<max;dy++)for(int dz=-radius;dz<=radius&&mined<max;dz++){
            if(dx*dx+dy*dy+dz*dz>radSq)continue;Block b=world.getBlockAt(cx+dx,cy+dy,cz+dz);Material type=b.getType();
            if(type.isAir()||!wl.contains(type))continue;
            Collection<ItemStack> drops=b.getDrops(tool,player);
            if(doSmelt)drops=smelt(drops,type,cm);
            give(player,b,drops);b.setType(Material.AIR,false);mined++;}
    }
    private Collection<ItemStack> smelt(Collection<ItemStack> drops,Material type,dev.schoolmine.schoolmine.managers.ConfigManager cm){
        Material bb=cm.getSmeltResult(type);List<ItemStack> out=new ArrayList<>();
        for(ItemStack d:drops){if(d==null||d.getType().isAir())continue;Material r=bb!=null?bb:cm.getSmeltResult(d.getType());out.add(r!=null?new ItemStack(r,d.getAmount()):d);}return out;}
    private void give(Player player,Block block,Collection<ItemStack> drops){
        PlayerInventory inv=player.getInventory();
        for(ItemStack d:drops){if(d==null||d.getType().isAir())continue;HashMap<Integer,ItemStack> lft=inv.addItem(d.clone());if(!lft.isEmpty())for(ItemStack l:lft.values())block.getWorld().dropItemNaturally(block.getLocation(),l);}}
    private boolean sameBlock(Location a,Location b){return a.getBlockX()==b.getBlockX()&&a.getBlockY()==b.getBlockY()&&a.getBlockZ()==b.getBlockZ()&&a.getWorld()==b.getWorld();}
}
