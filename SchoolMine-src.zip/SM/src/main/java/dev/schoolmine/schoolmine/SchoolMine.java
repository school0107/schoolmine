package dev.schoolmine.schoolmine;
import dev.schoolmine.schoolmine.commands.*;
import dev.schoolmine.schoolmine.listeners.*;
import dev.schoolmine.schoolmine.managers.*;
import org.black_ixx.playerpoints.PlayerPoints;
import org.black_ixx.playerpoints.PlayerPointsAPI;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.File;
public final class SchoolMine extends JavaPlugin {
    private static SchoolMine instance;
    private ConfigManager configManager;
    private PlayerDataManager playerDataManager;
    private BlockRemoveManager blockRemoveManager;
    private BoosterManager boosterManager;
    private PlayerPointsAPI playerPointsAPI;
    private NukerTask nukerTask;
    private AutoMineTask autoMineTask;
    private YamlConfiguration boosterConfig;
    private File boosterConfigFile;

    @Override public void onEnable() {
        instance = this;
        saveDefaultConfig();
        loadBoosterConfig();
        configManager = new ConfigManager(this);
        playerDataManager = new PlayerDataManager(this);
        blockRemoveManager = new BlockRemoveManager(this);
        boosterManager = new BoosterManager(this);

        if (Bukkit.getPluginManager().getPlugin("PlayerPoints") != null) {
            playerPointsAPI = PlayerPoints.getInstance().getAPI();
            getLogger().info("Hooked into PlayerPoints!");
        } else {
            getLogger().warning("PlayerPoints not found! Booster purchase disabled.");
        }

        reg("autopickup", new AutoPickupCommand(this));
        reg("3x3", new Mining3x3Command(this));
        reg("autosmelt", new AutoSmeltCommand(this));
        reg("automine", new AutoMineCommand(this));
        reg("schoolmine", new SchoolMineCommand(this));
        reg("booster", new BoosterCommand(this));

        Bukkit.getPluginManager().registerEvents(new BlockBreakListener(this), this);
        Bukkit.getPluginManager().registerEvents(new BlockPlaceListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerQuitListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        Bukkit.getPluginManager().registerEvents(new BoosterMenuListener(this), this);
        Bukkit.getPluginManager().registerEvents(new KillShardListener(this), this);

        nukerTask = new NukerTask(this); nukerTask.start();
        autoMineTask = new AutoMineTask(this); autoMineTask.start();

        int interval = configManager.getAutoSaveInterval();
        if (interval > 0) Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> playerDataManager.saveAll(), interval * 20L, interval * 20L);

        getLogger().info("SchoolMine v1.0.0 enabled!");
    }

    @Override public void onDisable() {
        if (playerDataManager != null) playerDataManager.saveAll();
        if (blockRemoveManager != null) blockRemoveManager.shutdown();
        if (boosterManager != null) boosterManager.shutdown();
        if (nukerTask != null) nukerTask.stop();
        if (autoMineTask != null) autoMineTask.stop();
        getLogger().info("SchoolMine disabled.");
    }

    private void reg(String name, Object cmd) {
        var c = getCommand(name); if (c == null) return;
        if (cmd instanceof org.bukkit.command.CommandExecutor ex) c.setExecutor(ex);
        if (cmd instanceof org.bukkit.command.TabCompleter tc) c.setTabCompleter(tc);
    }

    public void reload() {
        reloadConfig(); configManager.reload();
        playerDataManager.saveAll(); playerDataManager.clearCache();
        blockRemoveManager.reload(); reloadBoosterConfig();
    }

    private void loadBoosterConfig() {
        boosterConfigFile = new File(getDataFolder(), "booster.yml");
        if (!boosterConfigFile.exists()) { getDataFolder().mkdirs(); saveResource("booster.yml", false); }
        boosterConfig = YamlConfiguration.loadConfiguration(boosterConfigFile);
    }

    public void reloadBoosterConfig() { loadBoosterConfig(); }
    public YamlConfiguration getBoosterConfig() { if (boosterConfig == null) loadBoosterConfig(); return boosterConfig; }

    public static SchoolMine getInstance() { return instance; }
    public ConfigManager getConfigManager() { return configManager; }
    public PlayerDataManager getPlayerDataManager() { return playerDataManager; }
    public BlockRemoveManager getBlockRemoveManager() { return blockRemoveManager; }
    public BoosterManager getBoosterManager() { return boosterManager; }
    public PlayerPointsAPI getPlayerPointsAPI() { return playerPointsAPI; }
}
