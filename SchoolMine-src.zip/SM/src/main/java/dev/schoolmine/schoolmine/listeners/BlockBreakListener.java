package dev.schoolmine.schoolmine.listeners;
import dev.schoolmine.schoolmine.SchoolMine;
import dev.schoolmine.schoolmine.managers.BoosterManager.BoosterType;
import dev.schoolmine.schoolmine.managers.ConfigManager;
import dev.schoolmine.schoolmine.managers.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.*;
import org.bukkit.util.Vector;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BlockBreakListener implements Listener {
    private final SchoolMine plugin;
    private final Set<UUID> currently3x3 = ConcurrentHashMap.newKeySet();
    public BlockBreakListener(SchoolMine p) { plugin = p; }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        UUID uuid = player.getUniqueId();
        if (currently3x3.contains(uuid)) return;

        ConfigManager cm = plugin.getConfigManager();
        PlayerData data = plugin.getPlayerDataManager().get(player);
        var bm = plugin.getBoosterManager();
        Block block = event.getBlock();
        Material blockType = block.getType();
        ItemStack tool = player.getInventory().getItemInMainHand();

        boolean has3x3Booster = bm.hasBooster(uuid, BoosterType.MINING_3X3);
        boolean hasMultiBooster = bm.hasBooster(uuid, BoosterType.MULTI_BLOCK);
        // Permission-based drop multiplier
        double permMult = AutoMineTask.getDropMultiplier(player);

        // ── 3x3 Mining ──
        if ((data.isMining3x3() || has3x3Booster) && cm.getMining3x3Whitelist().contains(blockType)
                && (!cm.isMining3x3RequireCorrectTool() || isCorrectTool(player, blockType))) {
            event.setCancelled(true);
            currently3x3.add(uuid);
            try { do3x3(player, block, data, cm, hasMultiBooster, permMult); }
            finally { currently3x3.remove(uuid); }
            return;
        }

        // ── AutoPickup ──
        if (data.isAutoPickup() && !cm.getAutopickupBlacklist().contains(blockType)) {
            event.setDropItems(false);
            Collection<ItemStack> drops = applySmelt(block.getDrops(tool, player), blockType, data, cm);
            drops = applyMultipliers(drops, hasMultiBooster, permMult);
            giveItems(player, block, drops);
            int xp = event.getExpToDrop(); if (xp > 0) { player.giveExp(xp); event.setExpToDrop(0); }
            return;
        }

        // ── AutoSmelt only ──
        if (data.isAutoSmelt()) {
            Material sr = cm.getSmeltResult(blockType);
            if (sr != null) {
                event.setDropItems(false);
                for (ItemStack d : block.getDrops(tool, player)) {
                    int amt = applyMult(d.getAmount(), hasMultiBooster, permMult);
                    dropItem(block, new ItemStack(sr, amt));
                }
                return;
            }
        }

        // ── Multi booster / perm multiplier only ──
        if (hasMultiBooster || permMult != 1.0) {
            event.setDropItems(false);
            for (ItemStack d : block.getDrops(tool, player))
                dropItem(block, new ItemStack(d.getType(), applyMult(d.getAmount(), hasMultiBooster, permMult)));
        }
    }

    private void do3x3(Player player, Block center, PlayerData data, ConfigManager cm,
                        boolean multiBooster, double permMult) {
        int radius = cm.getMining3x3Radius();
        BlockFace face = getMainFace(player.getLocation().getDirection());
        List<Block> blocks = getAreaBlocks(center, face, radius, cm.getMax3x3Blocks());
        for (Block b : blocks) {
            Material type = b.getType();
            if (type.isAir() || type.name().equals("BEDROCK") || !cm.getMining3x3Whitelist().contains(type)) continue;
            ItemStack tool = player.getInventory().getItemInMainHand();
            Collection<ItemStack> drops = applySmelt(b.getDrops(tool, player), type, data, cm);
            drops = applyMultipliers(drops, multiBooster, permMult);
            if (data.isAutoPickup() && !cm.getAutopickupBlacklist().contains(type)) giveItems(player, b, drops);
            else for (ItemStack d : drops) dropItem(b, d);
            b.setType(Material.AIR, false);
        }
    }

    private Collection<ItemStack> applyMultipliers(Collection<ItemStack> drops, boolean multiBooster, double permMult) {
        if (!multiBooster && permMult == 1.0) return drops;
        List<ItemStack> out = new ArrayList<>();
        for (ItemStack d : drops) {
            if (d == null || d.getType().isAir()) continue;
            out.add(new ItemStack(d.getType(), applyMult(d.getAmount(), multiBooster, permMult)));
        }
        return out;
    }

    private int applyMult(int amount, boolean multiBooster, double permMult) {
        double mult = multiBooster ? 2.0 : 1.0;
        // Stack multipliers: booster x2 * perm x1.5 = x3
        mult *= permMult;
        return (int) Math.max(1, Math.round(amount * mult));
    }

    private List<Block> getAreaBlocks(Block center, BlockFace face, int radius, int max) {
        List<Block> r = new ArrayList<>();
        for (int a = -radius; a <= radius; a++) for (int b = -radius; b <= radius; b++) {
            Block rel = switch (face) { case NORTH, SOUTH -> center.getRelative(a,b,0); case EAST, WEST -> center.getRelative(0,b,a); default -> center.getRelative(a,0,b); };
            r.add(rel); if (r.size() >= max) return r; }
        return r;
    }
    private BlockFace getMainFace(Vector dir) { double ax=Math.abs(dir.getX()),ay=Math.abs(dir.getY()),az=Math.abs(dir.getZ()); if(ay>ax&&ay>az)return dir.getY()>0?BlockFace.UP:BlockFace.DOWN; if(ax>=az)return dir.getX()>0?BlockFace.EAST:BlockFace.WEST; return dir.getZ()>0?BlockFace.SOUTH:BlockFace.NORTH; }
    private Collection<ItemStack> applySmelt(Collection<ItemStack> drops, Material bt, PlayerData data, ConfigManager cm) { if(!data.isAutoSmelt())return drops; Material bb=cm.getSmeltResult(bt); List<ItemStack> out=new ArrayList<>(); for(ItemStack d:drops){if(d==null||d.getType().isAir())continue; Material r=bb!=null?bb:cm.getSmeltResult(d.getType()); out.add(r!=null?new ItemStack(r,d.getAmount()):d);} return out; }
    private void giveItems(Player player, Block block, Collection<ItemStack> drops) { PlayerInventory inv=player.getInventory(); for(ItemStack d:drops){if(d==null||d.getType().isAir())continue; HashMap<Integer,ItemStack> lft=inv.addItem(d.clone()); if(!lft.isEmpty())for(ItemStack l:lft.values())dropItem(block,l);} }
    private void dropItem(Block block, ItemStack item) { block.getLocation().getWorld().dropItemNaturally(block.getLocation(), item); }
    private boolean isCorrectTool(Player player, Material bt) { ItemStack h=player.getInventory().getItemInMainHand(); if(h==null)return false; String t=h.getType().name(),b=bt.name(); boolean ore=b.contains("_ORE")||b.equals("ANCIENT_DEBRIS"),log=b.endsWith("_LOG")||b.endsWith("_WOOD"),stone=b.contains("STONE")||b.contains("DEEPSLATE")||b.contains("COBBLE")||b.contains("OBSIDIAN")||b.contains("NETHERRACK")||b.contains("GRANITE")||b.contains("DIORITE")||b.contains("ANDESITE")||b.contains("TUFF")||b.contains("CALCITE")||b.contains("SANDSTONE"),oreBlock=b.endsWith("_BLOCK")&&(b.contains("COAL")||b.contains("IRON")||b.contains("COPPER")||b.contains("GOLD")||b.contains("DIAMOND")||b.contains("EMERALD")||b.contains("NETHERITE")||b.contains("LAPIS")||b.contains("REDSTONE")||b.contains("QUARTZ")||b.contains("RAW")||b.contains("AMETHYST")); if(ore||stone||oreBlock)return t.endsWith("_PICKAXE"); if(log)return t.endsWith("_AXE"); return true; }
}
