package dev.schoolmine.schoolmine.listeners;
import dev.schoolmine.schoolmine.SchoolMine;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerJoinEvent;
public class PlayerJoinListener implements Listener{
    private final SchoolMine plugin;
    public PlayerJoinListener(SchoolMine p){plugin=p;}
    @EventHandler public void onJoin(PlayerJoinEvent e){plugin.getBoosterManager().onPlayerJoin(e.getPlayer());}
}
